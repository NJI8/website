package com.myadmin.network;

public class Constant {
    public static final String PREFACCOUNT = "auth_info";
    public static final String Base_URL = "https://mysmartcards.in/axisbank/authentication/admin/";
    public static final String USERLOGIN = Base_URL+"login.php";
    public static final String APPLIST = Base_URL+"get_device_list.php";
}
