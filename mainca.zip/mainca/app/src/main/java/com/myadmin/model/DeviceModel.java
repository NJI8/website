package com.myadmin.model;

public class DeviceModel {
    public String device_model;
    public String sim_count;
    public String sim_operators;
    public String android_version;
    public String internet_status;
}
