package com.myadmin.model;

public class UserModel {
    private String id;
    private String username;
    private String mobile;
    private String dob;

    public String getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getMobile() {
        return mobile;
    }

    public String getDob() {
        return dob;
    }
}
